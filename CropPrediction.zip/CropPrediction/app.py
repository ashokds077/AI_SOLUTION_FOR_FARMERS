import streamlit as st
import numpy as np
import pickle
import os
from PIL import Image

# Function to predict crop and season using Naive Bayes model
def predict_crop_and_season(N, P, K, temperature, humidity, ph, rainfall):
    data = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
    prediction = NaiveBayes.predict(data)

    # Determine season based on all factors
    if (temperature > 30) and (humidity > 70) and (rainfall > 200) and (N > 100) and (P > 20) and (K > 30):
        season = 'Monsoon'
    elif (temperature > 25) and (humidity > 50) and (rainfall < 100) and (N < 50) and (P < 15) and (K < 25):
        season = 'Summer'
    elif (temperature < 20) and (humidity < 40) and (rainfall < 100) and (N < 80) and (P > 10) and (K > 20):
        season = 'Winter'
    else:
        season = 'Fall'  # Uncertain

    return prediction[0], season

def load_naive_bayes_model():
    # Load the Naive Bayes model CropPrediction/models/NBClassifier.pkl
    with open('models/NBClassifier.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    return model

# Load the Naive Bayes model
NaiveBayes = load_naive_bayes_model()

def main():
    st.title("PrecisionPlantAI: Enhancing Crop Selection and Planting Timings")

    # Display image
    image = Image.open('crops.jpg')
    st.image(image, caption='Crops', use_column_width=True)

    # Specific threshold values for temperature, humidity, rainfall, N, P, and K
    N = st.slider("Ratio of Nitrogen content in soil (kg/ha)", min_value=0, max_value=200, step=1)
    P = st.slider("Ratio of Phosphorous content in soil (kg/ha)", min_value=0, max_value=200, step=1)
    K = st.slider("Ratio of Potassium content in soil (kg/ha)", min_value=0, max_value=200, step=1)
    temperature = st.slider("Temperature (°C)", min_value=0, max_value=40, step=1)
    humidity = st.slider("Relative Humidity (%)", min_value=0, max_value=100, step=1)
    ph = st.slider("Soil pH", min_value=0, max_value=14, step=1)  # Adjusted step to 1
    rainfall = st.slider("Rainfall (mm)", min_value=0, max_value=500, step=1)

    # Make a prediction using Naive Bayes model
    if st.button("Predict"):
        crop, season = predict_crop_and_season(N, P, K, temperature, humidity, ph, rainfall)
        st.success(f"The predicted crop is: {crop}")
        if season:
            st.info(f"Suggested season for planting: {season}")
        else:
            st.warning("Conditions do not match any specific season.")

if __name__ == "__main__":
    main()
